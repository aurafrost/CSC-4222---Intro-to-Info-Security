/* 
 * Programming Assignment 4
 * Jimmy Tran
 * Bourgeois
 * CSC 4222
 * 4 December 2017
 */
package jtran25PA4;
//imports
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.xml.bind.DatatypeConverter;

public class Jtran25PA4 {
    //pre: takes a non-empty string and key as a parameter
    //post: returns an AES-encrypted string as a byte array
    public static byte[] encryptionAES(String msg,SecretKey key)throws Exception{
        Cipher cipher = Cipher.getInstance("AES"); //sets cipher to AES
        cipher.init(Cipher.ENCRYPT_MODE, key); //encryption mode
        byte[] cText=cipher.doFinal(msg.getBytes()); //completes encryption
        return cText; //returns encrypted msg
    }
    
    //pre: takes an AES-encrypted string and key as a parameter
    //post: returns the decrypted string
    public static String decryptionAES(byte[] bText, SecretKey key) throws Exception{
        Cipher cipher = Cipher.getInstance("AES"); //sets cipher to AES
        cipher.init(Cipher.DECRYPT_MODE, key); //decryption mode
        byte[] bText2 = cipher.doFinal(bText); //completes decryption
        return new String(bText2); //returns decrypted message
    }
    
    //main method
    public static void main(String[] args) throws Exception {
        String msg="ProgrammingAssignment4"; //string to be encrypted
        
        KeyGenerator generator = KeyGenerator.getInstance("AES"); //sets generator to AES
        generator.init(128); // AES key size
        SecretKey key = generator.generateKey(); //generates a static key
        
        byte[] cText = encryptionAES(msg, key); //call encryption method
        String decryptedText = decryptionAES(cText, key); //call decryption method
        System.out.println("Message: " + msg); //prints original string
//        String hex=DatatypeConverter.printHexBinary(secKey.getEncoded());
//        System.out.println("AES Key (Hex Form):"+hex);
        String msghex=DatatypeConverter.printHexBinary(cText); //converts text to binary for printing
        System.out.println("Encrypted Message: "+msghex); //prints encrypted message
        System.out.println("Decrypted Message: "+decryptedText); //prints decrypted message
    }
}